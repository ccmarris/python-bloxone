=====
TO DO
=====

- Update b1.delete to support body
- Update b1tdc get_id and delete to support 'short IDs' and body for delete operations
- Add b1notifications class
- Encode/Decode to HEX for Option 43 functions to bloxone.utils
- Add tide_data_feed() method